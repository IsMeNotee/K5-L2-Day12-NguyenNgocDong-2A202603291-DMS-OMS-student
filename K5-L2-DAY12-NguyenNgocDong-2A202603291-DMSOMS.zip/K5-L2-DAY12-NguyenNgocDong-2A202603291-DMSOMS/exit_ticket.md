# Exit ticket — Ngày 12

Bản đáp án tham khảo được AI hỗ trợ theo yêu cầu của người làm; đã khai báo trong prompts.md. Người làm cần tự kiểm lại trước khi nộp.

**Họ tên:** Nguyễn Ngọc Đồng — 2A202603291 · **Mã:** G02

---

**Câu 1 · Chọn một.** Camera DMS trên nhiều xe tự chiếu đèn LED cận hồng ngoại khoảng 940 nm lên mặt tài xế. Lý do chính là gì?

- A. Để đo nhiệt độ da và phát hiện tài xế bị sốt
- B. Để có ảnh mặt ổn định cả ngày lẫn đêm mà không làm chói mắt tài xế
- C. Để có ảnh màu đẹp hơn cho cuộc gọi video
- D. Để camera nhìn xuyên qua mọi loại kính râm

Đáp án: **B**.

Chiếu sáng NIR chủ động giúp camera quan sát mặt trong điều kiện ngày và đêm, không cần đèn nhìn thấy chiếu chói vào tài xế. Đây không phải phép đo nhiệt độ và không bảo đảm nhìn xuyên mọi kính râm.

**Câu 2 · Số, 2 chữ số thập phân.** Camera DMS chạy 30 khung hình/giây. Model ước lượng yaw của đầu tài xế lớn hơn 30° liên tục từ khung hình số 240 đến khung hình số 314, **tính cả khung 240 và khung 314**. Tài xế không nhìn đường trong bao nhiêu giây?

Đáp án: **2,50 s**.

Số khung tính cả hai đầu: 314 − 240 + 1 = 75 khung. Thời lượng: 75 / 30 = 2,50 giây.

**Câu 3 · Chọn tất cả đáp án đúng.** Những câu nào đúng về dữ liệu cabin so với dữ liệu camera ngoài xe?

- A. Không thể làm mờ mặt tài xế như làm mờ mặt người qua đường, vì model DMS cần chính khuôn mặt.
- B. Ban đêm, ảnh cabin thường là ảnh hồng ngoại đen trắng, nên thuộc tính màu áo không gán được.
- C. Camera OMS nhìn về phía sau xe, nên ghế ở bên trái ảnh là ghế bên phải của xe.
- D. Vật trong cabin thường ở xa và nhỏ, nhiều vật trong một ảnh.
- E. Cảnh cabin cố định nên không cần guideline hay QC riêng.

Đáp án: **A, B, C**.

A đúng trong ngữ cảnh dữ liệu đầu vào cần chi tiết mặt cho DMS; làm mờ mất đặc trưng cần phân tích. B đúng vì ảnh NIR không cung cấp màu áo như RGB. C đúng với camera OMS nhìn về sau trong bài. D không mô tả đặc trưng cabin của bài (camera gần người và ghế). E sai vì vẫn cần guideline và QC riêng.
