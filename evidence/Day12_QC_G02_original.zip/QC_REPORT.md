# QC_REPORT — Day 12 DMS & OMS (G02)

**Ngày QC:** 21/11/2026  
**Người thực hiện bài:** Nguyễn Ngọc Đồng — 2A202603291  
**Người review chéo được chỉ định:** **Đặng Thu Thúy — 2A202603263**  
**Trạng thái xác nhận của người review chéo:** Chưa nhận được xác nhận hoặc bản export độc lập của người review.  
**Hỗ trợ rà soát kỹ thuật:** ChatGPT — phân tích XML, chạy QC và đối chiếu các nhận xét lần trước; không thay thế biên bản review chéo đã xác nhận.

## 1. Phạm vi và dữ liệu

| File được rà soát | Phạm vi | Kết quả |
|---|---|---|
| `Day12(1).zip` | 22 ảnh bắt buộc (S01–S08 RGB/IR; D01–D06) | **Đủ 22/22** |
| `Day12_Extra(1).zip` | 4 ảnh mở rộng (S09–S10 RGB/IR) | **Đủ 4/4** |

- Cả hai ZIP đều chỉ chứa `annotations.xml`, định dạng CVAT for images 1.1; **không chứa ảnh**.
- Mỗi ảnh có **chính xác một `frame_meta`**; `modality` khớp tên file, toàn bộ OMS có `light=unknown`.
- Bài chính có **6 skeleton `face13`**, mỗi skeleton đủ 13 mốc, **12 BBox tay** đều thuộc ảnh DMS (không còn BBox `hand` trên OMS).
- Số lượng BBox/skeleton trong bài chính: `child_seat`: 12, `face`: 6, `face13`: 6, `hand`: 12, `infant_seat`: 4, `object`: 10, `person`: 10.
- Phần mở rộng: `child_seat`: 4, `infant_seat`: 2.

## 2. Kết quả kiểm tra tự động

| Bộ kiểm tra | Bài chính | Mở rộng | Ý nghĩa |
|---|---|---|---|
| Checker cũ kèm G02 (chưa hỗ trợ `occupied=yes`) | **10 ERROR / 0 WARN** | **4 ERROR / 0 WARN** | Tất cả ERROR thuộc cùng một nguyên nhân: `child_seat.occupied=yes` chưa có trong danh sách hợp lệ của schema cũ |
| Cùng checker, chỉ bổ sung `yes` vào schema theo JSON mới | **0 ERROR / 0 WARN** | **0 ERROR / 0 WARN** | Đạt kiểm tra cấu trúc và quy tắc tự động theo schema mới |

**Quan trọng:** Không sửa XML để né lỗi. Phép thử tương thích chỉ cập nhật danh sách thuộc tính trong bản sao cục bộ của `cabin_schema.py`. File `labels_cabin_v1(1).json` do lớp gửi chứa `occupied = [unknown, no, yes]`; repo và validator cũ còn `[unknown, no]`. Cần thống nhất phiên bản với coach trước khi coi là đạt bộ chấm chính thức.

File QC tương ứng: `check_cpA.txt`, `check_cpB.txt`, `check_final.txt`, `check_extra.txt`; riêng `check_final_unmodified_checker.txt` lưu đầu ra của checker chưa cập nhật để đối chiếu. **`check_final.txt` là kết quả đã cập nhật schema, được ghi rõ nguồn và giới hạn.**

## 3. Xác nhận thay đổi sau lần review trước

| Vấn đề | Ảnh | Tình trạng trên ZIP mới |
|---|---|---|
| Face bị tóc che gần hết, cần bỏ box | S01 RGB/IR; S07 RGB/IR | **Đã sửa:** xóa 4 BBox `face` |
| Gán tay ở OMS (không thuộc phạm vi) | S01 RGB/IR; S07 IR | **Đã sửa:** xóa 6 BBox `hand` |
| `light=day/night` với OMS dựng | S01–S08 RGB và S09–S10 RGB | **Đã sửa:** tất cả về `unknown` |
| `camera_blocked=yes` chưa có cơ sở | S03 RGB | **Đã sửa:** về `no` |
| `eye_right=open` dù các điểm mắt phải đều che | D03 | **Đã sửa:** `eye_right=unknown` |
| `on_wheel=yes` ở tay không chạm vô lăng | D03 | **Đã sửa:** cả hai tay chuyển sang `no` |
| `eye_left/right=unknown` không phù hợp trạng thái điểm | D04, D06 | **Đã chỉnh:** chuyển sang `open/open` — vẫn cần xác nhận khi zoom mắt trên CVAT |
| Mép trên box `infant_seat` IR quá thấp | S02 IR | **Đã điều chỉnh:** y trên từ 349.15 lên 331.20; so với RGB y=286.90, nên kiểm tra lại trên CVAT |
| BBox `object` có chênh lệch giữa RGB và IR | S07 RGB/IR | **Chưa sửa:** mép dưới RGB y=524.01, IR y=601.45; cần xác định chênh lệch do hiển thị hay lỗi box |
| `infant_seat.facing` cần khẳng định theo chiều xe | S10 RGB/IR | **Chưa thay đổi:** vẫn `front`, cần xác nhận ảnh gốc và guideline |

## 4. Nhận xét về chất lượng

**Đạt phần kiểm tra cấu trúc và thuộc tính theo schema mới.** Các lỗi sai phạm vi nhãn và các thuộc tính được chỉ ra ở lần trước đã được xử lý. Bộ xuất không chứa ảnh, số lượng ảnh, tag và skeleton đầy đủ. Lần kiểm tra tự động mới cho kết quả **0 lỗi và 0 cảnh báo** sau khi chỉ cập nhật `occupied=yes` trong schema.

**Chưa xác nhận đạt tuyệt đối về chất lượng thị giác:** vẫn cần xem lại BBox của S02 IR và S07 RGB/IR; xác nhận hướng ghế S10; kiểm tra mắt D04/D06 ở mức zoom đủ lớn. Checker không đo được độ chính xác từng BBox và landmark so với nội dung ảnh.

**Lưu ý về `occupied=yes`:** dùng khi có trẻ ngồi trong ghế, không phải khi bị che. JSON được gửi bổ sung hỗ trợ giá trị này, nhưng guideline/validator công khai chưa đồng bộ. Không đổi `yes` về `no` chỉ để tránh lỗi script cũ.

## 5. Kết luận và việc còn lại

- **Tình trạng QC kỹ thuật:** ĐẠT **có điều kiện**, theo schema bổ sung `occupied=yes`.
- **Cần xác nhận:** (1) coach đồng ý với schema có `yes`; (2) kiểm tra trực quan S02 IR, S07 RGB/IR, S10 và mắt D04/D06.
- **Peer review E3:** chưa đủ dữ liệu để chạy `cabin_check diff`, vì chưa có bản export độc lập từ Đặng Thu Thúy. Không điền số bất đồng hoặc kết luận đối chiếu hai người khi chưa chạy diff.
- **Bản export gốc:** giữ nguyên; báo cáo QC này không thay đổi nhãn, điểm hoặc BBox của bạn.

**Người review chéo được khai báo:** Đặng Thu Thúy — 2A202603263.  
**Xác nhận review chéo:** Chờ người được chỉ định xem và xác nhận.
