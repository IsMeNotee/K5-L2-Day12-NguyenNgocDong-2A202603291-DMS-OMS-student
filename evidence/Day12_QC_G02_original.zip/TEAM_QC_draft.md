# TEAM — Day 12 (G02)

- Người gán nhãn: Nguyễn Ngọc Đồng — 2A202603291.
- Người review chéo được chỉ định: **Đặng Thu Thúy — 2A202603263**.
- Mã bộ dữ liệu: G02.
- Phạm vi: 22 ảnh chính S01–S08 RGB/IR, D01–D06. S09–S10 là phần mở rộng riêng.
- QC kỹ thuật: đã rà XML và chạy checker; chi tiết xem `QC_REPORT.md`.
- Review chéo độc lập: **chờ xác nhận từ Đặng Thu Thúy và bản xuất CVAT của bạn ấy để chạy diff**.
